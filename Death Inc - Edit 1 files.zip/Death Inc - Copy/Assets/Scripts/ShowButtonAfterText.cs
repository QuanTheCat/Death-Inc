﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowButtonAfterText : MonoBehaviour {
    class System.Index
	// Use this for initialization
	void Start () {
       if(System.IndexOutOfRangeException: System.Array index is out of range){

        }
        }

    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
